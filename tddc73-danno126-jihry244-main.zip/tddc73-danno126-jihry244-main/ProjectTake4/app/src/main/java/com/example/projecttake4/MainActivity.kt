package com.example.projecttake4

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.AttributeSet
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.core.view.isVisible
import androidx.core.widget.doOnTextChanged

class MainActivity() : AppCompatActivity(), Parcelable {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewInitializations()
    }
    lateinit var etFirstName: EditText
    lateinit var etLastName: EditText
    lateinit var etEmail: EditText
    lateinit var etPassword: EditText
    lateinit var etRepeatPassword: EditText
    lateinit var etDateOfBirth: EditText
    lateinit var etGender: Spinner
    lateinit var etNumber: EditText
    val MIN_PASSWORD_LENGTH = 6;
    var requireDateOfBirth = false
    var requireGender = false
    var requireNumber = false

    var minLength = 8
    var maxLength = 128
    var requireLowercaseLetters = true
    var requireUppercaseLetters = true
    var requireSpecialCharacters = true
    var requireNumbers = true
    var errorMessage = "enter password"
    var length = 0
    val uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val lowercase = "abcdefghijklmnopqrstuvwxyz"
    val numbers = "0123456789"

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    constructor(parcel: Parcel) : this() {
        requireDateOfBirth = parcel.readByte() != 0.toByte()
        requireGender = parcel.readByte() != 0.toByte()
        requireNumber = parcel.readByte() != 0.toByte()
        minLength = parcel.readInt()
        maxLength = parcel.readInt()
        requireLowercaseLetters = parcel.readByte() != 0.toByte()
        requireUppercaseLetters = parcel.readByte() != 0.toByte()
        requireSpecialCharacters = parcel.readByte() != 0.toByte()
        requireNumbers = parcel.readByte() != 0.toByte()
        errorMessage = parcel.readString().toString()
        length = parcel.readInt()
    }

    //constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    fun viewInitializations() {
        etFirstName = findViewById(R.id.et_first_name)
        etLastName = findViewById(R.id.et_last_name)
        etEmail = findViewById(R.id.et_email)
        etPassword = findViewById(R.id.et_password)
        etRepeatPassword = findViewById(R.id.et_repeat_password)
        etDateOfBirth = findViewById(R.id.et_date_of_birth)
        etGender = findViewById(R.id.et_gender)
        etNumber = findViewById(R.id.et_number)

        // To show back button in actionbar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    // Checking if the input in form is valid
    fun validateInput(): Boolean {
        if (etFirstName.text.toString().equals("")) {
            etFirstName.setError("Please Enter First Name")
            return false
        }
        if (etLastName.text.toString().equals("")) {
            etLastName.setError("Please Enter Last Name")
            return false
        }
        if (etEmail.text.toString().equals("")) {
            etEmail.setError("Please Enter Email")
            return false
        }
        if (etPassword.text.toString().equals("")) {
            etPassword.setError("Please Enter Password")
            return false
        }
        if (etRepeatPassword.text.toString().equals("")) {
            etRepeatPassword.setError("Please Enter Repeat Password")
            return false
        }

        // checking the proper email format
        if (!isEmailValid(etEmail.text.toString())) {
            etEmail.setError("Please Enter Valid Email")
            return false
        }
        if (!isNumberValid(etNumber.text.toString())){
            etNumber.setError("Please Enter Valid Number")
            return false
        }
        // checking minimum password Length
        if (etPassword.text.length < MIN_PASSWORD_LENGTH) {
            etPassword.setError("Password Length must be more than " + MIN_PASSWORD_LENGTH + "characters")
            return false
        }

        // Checking if repeat password is same
        if (!etPassword.text.toString().equals(etRepeatPassword.text.toString())) {
            etRepeatPassword.setError("Password does not match")
            return false
        }

        return true
    }

    fun isEmailValid(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isNumberValid(number: String): Boolean{
        return Patterns.PHONE.matcher(number).matches()
    }

    fun SetRequireDateOfBirth(requireDateOfBirth: Boolean){
        this.requireDateOfBirth = requireDateOfBirth
        etDateOfBirth.isVisible = requireDateOfBirth
        etDateOfBirth.isActivated = requireDateOfBirth
    }

    fun SetRequireGender(requireGender: Boolean){
        this.requireGender = requireGender
        etGender.isVisible = requireGender
        etGender.isActivated = requireGender
    }
    fun SetRequireNumber(requireNumber: Boolean){
        this.requireNumber = requireNumber
        etNumber.isVisible = requireNumber
        etNumber.isActivated = requireNumber
    }

    // Hook Click Event

    fun performSignUp (view: View) {
        if (validateInput()) {

            // Input is valid, here send data to your server

            val firstName = etFirstName.text.toString()
            val lastName = etLastName.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val repeatPassword = etRepeatPassword.text.toString()

            //Toast.makeText(this,"Login Success",Toast.LENGTH_SHORT).show()
            print("Account registration success!\n")
        }
    }

    fun Setup(password: EditText, button: Button){
        password.doOnTextChanged { text, start, before, count -> button.isEnabled = CheckPasswordStrength(text.toString())}
        /*password.addTextChangedListener(object: TextWatcher{
            override fun afterTextChanged(s: Editable?) {
                //pass
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //pass
            }

            //when the user writes the password, check if it's strong enough, and maybe activate the button.
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                button.isEnabled = CheckPasswordStrength(s.toString())
            }
        })*/
    }

    override fun onDraw(canvas: Canvas){
        super.onDraw(canvas)

        var displayText = errorMessage
        //If there is no error, write the password strength
        if (displayText == ""){
            if(length-minLength > 8){
                displayText = "strength: excellent"
            } else if(length-minLength > 4){
                displayText = "strength: good"
            } else {
                displayText = "strength: okay"
            }
        }
        canvas.drawText(displayText, 10f, 40f, paint)
    }

    fun SetMinLength(minLength: Int){
        this.minLength = minLength
    }

    fun SetMaxLength(maxLength: Int){
        this.maxLength = maxLength
    }

    fun SetRequireLowercase(requireLowercase: Boolean){
        this.requireLowercaseLetters = requireLowercase
    }

    fun SetRequireUppercase(requireUppercase: Boolean){
        this.requireUppercaseLetters = requireUppercase
    }

    fun SetRequireNumbers(requireNumbers: Boolean){
        this.requireNumbers = requireNumbers
    }

    fun SetRequireSpecialCharacters(requireSpecialCharacters: Boolean){
        this.requireSpecialCharacters = requireSpecialCharacters
    }

    fun CheckPasswordStrength(password: String): Boolean{
        length = password.length
        if(password.length < minLength){
            errorMessage = "Password must be at least " + minLength + " characters long"
            return false
        } else if(password.length > maxLength){
            errorMessage = "Password may be at most " + maxLength + "characters long"
            return false
        }
        var containsUppercase = false
        var containsLowercase = false
        var containsNumber = false
        var containsSpecial = false
        for (character in password){
            if(uppercase.contains(character)){
                containsUppercase = true
            } else if(lowercase.contains(character)){
                containsLowercase = true
            } else if(numbers.contains(character)){
                containsNumber = true
            } else{
                containsSpecial = true
            }
        }
        if(requireLowercaseLetters && !containsLowercase){
            errorMessage = "Password must contain a lowercase letter"
            return false
        } else if(requireUppercaseLetters && !containsUppercase){
            errorMessage = "Password must contain an uppercase letter"
            return false
        } else if (requireNumbers && !containsNumber){
            errorMessage = "Password must contain a number"
            return false
        } else if(requireSpecialCharacters && !containsSpecial){
            errorMessage = "Password must contain a special character"
            return false
        }

        errorMessage = ""
        return true
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeByte(if (requireDateOfBirth) 1 else 0)
        parcel.writeByte(if (requireGender) 1 else 0)
        parcel.writeByte(if (requireNumber) 1 else 0)
        parcel.writeInt(minLength)
        parcel.writeInt(maxLength)
        parcel.writeByte(if (requireLowercaseLetters) 1 else 0)
        parcel.writeByte(if (requireUppercaseLetters) 1 else 0)
        parcel.writeByte(if (requireSpecialCharacters) 1 else 0)
        parcel.writeByte(if (requireNumbers) 1 else 0)
        parcel.writeString(errorMessage)
        parcel.writeInt(length)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MainActivity> {
        override fun createFromParcel(parcel: Parcel): MainActivity {
            return MainActivity(parcel)
        }

        override fun newArray(size: Int): Array<MainActivity?> {
            return arrayOfNulls(size)
        }
    }
    /*
    public final fun registerButtonClick(temp: View){
        val accoutregistration: AccountRegistration = AccountRegistration()
        accoutregistration.validateInput()
    }*/
}