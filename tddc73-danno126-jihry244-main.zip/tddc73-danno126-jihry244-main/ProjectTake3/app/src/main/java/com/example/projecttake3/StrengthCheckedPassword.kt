package com.example.projecttake3

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.core.widget.doOnTextChanged

class StrengthCheckedPassword : View {
    var minLength = 8
    var maxLength = 128
    var requireLowercaseLetters = true
    var requireUppercaseLetters = true
    var requireSpecialCharacters = true
    var requireNumbers = true
    var errorMessage = "enter password"
    var length = 0
    val uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val lowercase = "abcdefghijklmnopqrstuvwxyz"
    val numbers = "0123456789"

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)


    fun Setup(password: EditText, button: Button){
        //when the user writes the password, check if it's strong enough, and maybe activate the button.
        password.doOnTextChanged { text, start, before, count -> button.isEnabled = CheckPasswordStrength(text.toString())}
    }

    override fun onDraw(canvas: Canvas){
        super.onDraw(canvas)

        var displayText = errorMessage
        //If there is no error, write the password strength
        if (displayText == ""){
            if(length-minLength > 8){
                displayText = "strength: excellent"
            } else if(length-minLength > 4){
                displayText = "strength: good"
            } else {
                displayText = "strength: okay"
            }
        }
        paint.textSize = 40F
        canvas.drawText(displayText, 10f, 50f, paint)

    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {

        setMeasuredDimension(300, 60)
    }

    fun SetMinLength(minLength: Int){
        this.minLength = minLength
    }

    fun SetMaxLength(maxLength: Int){
        this.maxLength = maxLength
    }

    fun SetRequireLowercase(requireLowercase: Boolean){
        this.requireLowercaseLetters = requireLowercase
    }

    fun SetRequireUppercase(requireUppercase: Boolean){
        this.requireUppercaseLetters = requireUppercase
    }

    fun SetRequireNumbers(requireNumbers: Boolean){
        this.requireNumbers = requireNumbers
    }

    fun SetRequireSpecialCharacters(requireSpecialCharacters: Boolean){
        this.requireSpecialCharacters = requireSpecialCharacters
    }

    fun CheckPasswordStrength(password: String): Boolean{
        length = password.length
        if(password.length < minLength){
            errorMessage = "Password must be at least " + minLength + " characters long"
            return false
        } else if(password.length > maxLength){
            errorMessage = "Password may be at most " + maxLength + "characters long"
            return false
        }
        var containsUppercase = false
        var containsLowercase = false
        var containsNumber = false
        var containsSpecial = false
        for (character in password){
            if(uppercase.contains(character)){
                containsUppercase = true
            } else if(lowercase.contains(character)){
                containsLowercase = true
            } else if(numbers.contains(character)){
                containsNumber = true
            } else{
                containsSpecial = true
            }
        }
        if(requireLowercaseLetters && !containsLowercase){
            errorMessage = "Password must contain a lowercase letter"
            return false
        } else if(requireUppercaseLetters && !containsUppercase){
            errorMessage = "Password must contain an uppercase letter"
            return false
        } else if (requireNumbers && !containsNumber){
            errorMessage = "Password must contain a number"
            return false
        } else if(requireSpecialCharacters && !containsSpecial){
            errorMessage = "Password must contain a special character"
            return false
        }

        errorMessage = ""
        return true
    }
}