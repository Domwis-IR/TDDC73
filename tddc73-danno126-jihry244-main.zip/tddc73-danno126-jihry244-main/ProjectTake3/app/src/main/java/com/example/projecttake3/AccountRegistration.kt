package com.example.projecttake3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.core.view.isVisible
import java.lang.reflect.GenericArrayType


class AccountRegistration {

    lateinit var etFirstName: EditText
    lateinit var etLastName:EditText
    lateinit var etEmail: EditText
    lateinit var etPassword:EditText
    lateinit var etRepeatPassword:EditText
    lateinit var etDateOfBirth: EditText
    lateinit var etGender: Spinner
    lateinit var etNumber: EditText
    val MIN_PASSWORD_LENGTH = 6;
    var requireDateOfBirth = false
    var requireGender = false
    var requireNumber = false

    /*override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_registration)

        viewInitializations()
    }*/

    fun viewInitializations(firstNameView: EditText, lastNameView: EditText, emailView: EditText, passwordView: EditText, repeatPasswordView: EditText, dateOfBirthView: EditText, genderView: Spinner, numberView: EditText) {
        etFirstName = firstNameView
        etLastName = lastNameView
        etEmail = emailView
        etPassword = passwordView
        etRepeatPassword = repeatPasswordView
        etDateOfBirth = dateOfBirthView
        etGender = genderView
        etNumber = numberView
    }

    /*fun viewInitializations() {
        etFirstName = findViewById(R.id.et_first_name)
        etLastName = findViewById(R.id.et_last_name)
        etEmail = findViewById(R.id.et_email)
        etPassword = findViewById(R.id.et_password)
        etRepeatPassword = findViewById(R.id.et_repeat_password)
        etDateOfBirth = findViewById(R.id.et_date_of_birth)
        etGender = findViewById(R.id.et_gender)
        etNumber = findViewById(R.id.et_number)

        // To show back button in actionbar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }*/

    // Checking if the input in form is valid
    fun validateInput(): Boolean {
        if (etFirstName.text.toString().equals("")) {
            etFirstName.error = "Please Enter First Name"
            return false
        }
        if (etLastName.text.toString().equals("")) {
            etLastName.error = "Please Enter Last Name"
            return false
        }
        if (etEmail.text.toString().equals("")) {
            etEmail.error = "Please Enter Email"
            return false
        }
        if (etPassword.text.toString().equals("")) {
            etPassword.error = "Please Enter Password"
            return false
        }
        if (etRepeatPassword.text.toString().equals("")) {
            etRepeatPassword.error = "Please Enter Repeat Password"
            return false
        }

        // checking the proper email format
        if (!isEmailValid(etEmail.text.toString())) {
            etEmail.error = "Please Enter Valid Email"
            return false
        }
        if (!isNumberValid(etNumber.text.toString())){
            etNumber.error = "Please Enter Valid Number"
            return false
        }
        // checking minimum password Length
        if (etPassword.text.length < MIN_PASSWORD_LENGTH) {
            etPassword.error = "Password Length must be more than " + MIN_PASSWORD_LENGTH + "characters"
            return false
        }

        // Checking if repeat password is same
        if (!etPassword.text.toString().equals(etRepeatPassword.text.toString())) {
            etRepeatPassword.error = "Password does not match"
            return false
        }

        return true
    }

    fun isEmailValid(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isNumberValid(number: String): Boolean{
        return Patterns.PHONE.matcher(number).matches()
    }

    fun SetRequireDateOfBirth(requireDateOfBirth: Boolean){
        this.requireDateOfBirth = requireDateOfBirth
        etDateOfBirth.isVisible = requireDateOfBirth
        etDateOfBirth.isActivated = requireDateOfBirth
    }

    fun SetRequireGender(requireGender: Boolean){
        this.requireGender = requireGender
        etGender.isVisible = requireGender
        etGender.isActivated = requireGender
    }
    fun SetRequireNumber(requireNumber: Boolean){
        this.requireNumber = requireNumber
        etNumber.isVisible = requireNumber
        etNumber.isActivated = requireNumber
    }

    // Hook Click Event

    fun performSignUp (view: View) {
        if (validateInput()) {

            // Input is valid, here send data to your server

            val firstName = etFirstName.text.toString()
            val lastName = etLastName.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val repeatPassword = etRepeatPassword.text.toString()

            //Toast.makeText(this,"Login Success",Toast.LENGTH_SHORT).show()
            print("Account registration success!\n")
        }
    }

}