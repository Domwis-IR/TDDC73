package com.example.projecttake3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Spinner

class MainActivity : AppCompatActivity() {
    val accoutregistration: AccountRegistration = AccountRegistration()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val passwordChecker = findViewById<StrengthCheckedPassword>(R.id.strengthCheckedPassword)
        passwordChecker.Setup(findViewById(R.id.et_password), findViewById(R.id.bt_register))
        //passwordChecker.SetMinLength(20)
        //passwordChecker.SetRequireSpecialCharacters(false)
        //passwordChecker.SetRequireUppercase(false)
        //passwordChecker.SetRequireNumbers(false)


        accoutregistration.viewInitializations(
            findViewById<EditText>(R.id.et_first_name),
            findViewById<EditText>(R.id.et_last_name),
            findViewById<EditText>(R.id.et_email),
            findViewById<EditText>(R.id.et_password),
            findViewById<EditText>(R.id.et_repeat_password),
            findViewById<EditText>(R.id.et_date_of_birth),
            findViewById<Spinner>(R.id.et_gender),
            findViewById<EditText>(R.id.et_number)
        )
        //You can decide whether you want to use these information in your form.
        //accoutregistration.SetRequireDateOfBirth(false)
        //accoutregistration.SetRequireGender(false)
        //accoutregistration.SetRequireNumber(false)
    }
    public final fun registerButtonClick(temp: View){
        accoutregistration.validateInput()
    }
}