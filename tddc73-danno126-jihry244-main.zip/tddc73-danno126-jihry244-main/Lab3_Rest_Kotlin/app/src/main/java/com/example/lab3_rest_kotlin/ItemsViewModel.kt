package com.example.lab3_rest_kotlin

data class ItemsViewModel(val name: String, val full_name: String, val description: String, val stargazers_count:String) {
}