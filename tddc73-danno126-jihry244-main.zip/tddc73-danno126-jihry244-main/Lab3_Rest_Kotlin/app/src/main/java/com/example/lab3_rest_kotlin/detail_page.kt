package com.example.lab3_rest_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.ActionBar

class detail_page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_page)

        val actionbar : ActionBar? = supportActionBar
        actionbar!!.setDisplayHomeAsUpEnabled(true)
        actionbar!!.setDisplayShowHomeEnabled(true)

        val intent = intent
        val bName = intent.getStringExtra("iName")
        val bFullname = intent.getStringExtra("iFullname")
        val bDescription = intent.getStringExtra("iDescription")
        val bStars = intent.getStringExtra("iStars")

        actionBar?.setTitle(bName)
        val detail_name = findViewById<TextView>(R.id.detail_name)
        detail_name.text = bName
        val detail_fullname = findViewById<TextView>(R.id.detail_fullname)
        detail_fullname.text = bFullname
        val detail_description = findViewById<TextView>(R.id.detail_description)
        detail_description.text = bDescription
        val detail_stars = findViewById<TextView>(R.id.detail_stars)
        detail_stars.text = bStars




    }
}