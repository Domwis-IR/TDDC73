package com.example.lab3_rest_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class MainActivity : AppCompatActivity(){

    val projects: HashMap<String, HashMap<String, String>> = HashMap()

    val languages: LinkedList<String> = LinkedList()

    val data = ArrayList<ItemsViewModel>()


    fun ProjectsOfLanguage(language: String): LinkedList<String> {
        val specificProjects: LinkedList<String> = LinkedList()
        if(language.equals("all languages")){
            for (projectName in projects.keys) {
                specificProjects.add(projectName)
            }
        } else {
            for (projectName in projects.keys) {
                if (projects.get(projectName)?.get("language").equals(language)) {
                    specificProjects.add(projectName)
                }
            }
        }
        return specificProjects
    }

    fun LanguageChanged(language: String){
        data.clear()
        for (projectName in ProjectsOfLanguage(language)) {
            val currentProject: HashMap<String, String> = projects.get(projectName)!!
            var name = "loading"
            var fullname = "loading"
            var description = "loading"
            var stars = "loading"
            currentProject.get("name")?.let { value -> name = value }
            currentProject.get("full_name")?.let { value -> fullname = value }
            currentProject.get("description")?.let { value -> description = value }
            currentProject.get("stargazers_count")?.let { value -> stars = value }
            data.add(ItemsViewModel(name, fullname, description, stars))
            // getting the recyclerview by its id
            val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)

            // this creates a vertical layout Manager
            recyclerview.layoutManager = LinearLayoutManager(this)


            // This will pass the ArrayList to our Adapter
            val adapter = CustomAdapter(data, this)

            // Setting the Adapter with the recyclerview
            recyclerview.adapter = adapter
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        languages.add("all languages")

        val queue = Volley.newRequestQueue(this)
        val url = "https://api.github.com/repositories"

        val request: JsonArrayRequest = object:JsonArrayRequest(
            Request.Method.GET, url, null,
            Response.Listener<JSONArray?> { response ->
                for (i in 0..response.length()-1){
                    val map:HashMap<String, String> = HashMap()
                    map.put("name", response.getJSONObject(i).getString("name"))
                    map.put("full_name", response.getJSONObject(i).getString("full_name"))
                    map.put("url", response.getJSONObject(i).getString("url"))
                    map.put("html_url", response.getJSONObject(i).getString("html_url"))
                    projects.put(response.getJSONObject(i).getString("full_name"), map)
                }


                for (projectName in projects.keys) {
                    val innerUrl = projects.get(projectName)?.get("url")

                    val innerRequest: JsonObjectRequest = object:JsonObjectRequest(
                        Request.Method.GET, innerUrl, null,
                        { innerResponse ->
                            projects.get(projectName)?.put("name", innerResponse.getString("name"))
                            projects.get(projectName)?.put("full_name", innerResponse.getString("full_name"))
                            projects.get(projectName)?.put("description", innerResponse.getString("description"))
                            projects.get(projectName)?.put("forks_count", innerResponse.getString("forks_count"))
                            projects.get(projectName)?.put("stargazers_count", innerResponse.getString("stargazers_count"))
                            val language = innerResponse.getString("language")
                            if(!languages.contains(language)){
                                languages.add(language)
                                val dropdown: Spinner = findViewById(R.id.spinner)
                                val adapter = ArrayAdapter(
                                    this,
                                    android.R.layout.simple_spinner_item,
                                    languages
                                )
                                dropdown.adapter = adapter
                                dropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                                    override fun onNothingSelected(parent: AdapterView<*>?) {

                                    }

                                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                        LanguageChanged(languages.get(position))
                                    }

                                }
                            }
                            projects.get(projectName)?.put("language", language)
                            if(innerResponse.has("license") && !innerResponse.get("license").equals(null) && innerResponse.getJSONObject("license").has("name")) {
                                projects.get(projectName)?.put("license", innerResponse.getJSONObject("license").getString("name"))
                            } else{
                                projects.get(projectName)?.put("license", "none")
                            }
                            projects.get(projectName)?.put("open_issues_count", innerResponse.getString("open_issues_count"))
                            projects.get(projectName)?.put("updated_at", innerResponse.getString("updated_at"))
                            println("\nFinished updating project: " + projectName)
                            println("now looks like: " + projects.get(projectName).toString())
                            val currentProject:HashMap<String, String> = projects.get(projectName)!!
                            data.add(ItemsViewModel(currentProject.get("name")!!, currentProject.get("full_name")!!, currentProject.get("description")!!, currentProject.get("stargazers_count")!!))
                            // getting the recyclerview by its id
                            val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)

                            // this creates a vertical layout Manager
                            recyclerview.layoutManager = LinearLayoutManager(this)

                            // This will pass the ArrayList to our Adapter
                            val adapter = CustomAdapter(data, this)

                            // Setting the Adapter with the recyclerview
                            recyclerview.adapter = adapter
                            /*
                            adapter.setOnItemClickListener(object: CustomAdapter.onItemClickListener{
                                override fun onItemClick(position: Int) {
                                    val intent = Intent(this, detail_page::class.java) {
                                    }
                                    startActivity(intent)
                                }
                            })
                            */
                        },
                        { println("Inner request failed somewhere") }) {
                        @Throws(AuthFailureError::class)
                        override fun getHeaders(): Map<String, String> {
                            val params: MutableMap<String, String> = HashMap()
                            params["Authorization"] = "Bearer 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"
                            //..add other headers
                            return params
                        }
                    }
                    queue.add(innerRequest)
                }
            }, Response.ErrorListener{ error ->
                println(error.message )
            }) {
            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String> {
                val params: MutableMap<String, String> = HashMap()
                params["Authorization"] = "Bearer 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"
                //..add other headers
                return params
            }
        }
        queue.add(request)

        }

}
