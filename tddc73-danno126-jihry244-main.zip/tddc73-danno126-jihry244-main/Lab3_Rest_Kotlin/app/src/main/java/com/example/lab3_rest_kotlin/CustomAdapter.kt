package com.example.lab3_rest_kotlin

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CustomAdapter(
    private val mList: List<ItemsViewModel>, val context: Context
) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {
    /*
    private lateinit var mListener: onItemClickListener

    interface onItemClickListener{
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: onItemClickListener){
        mListener = listener
    }*/
    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.card_view_design, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel = mList[position]

        // sets the text to the textview from our itemHolder class
        holder.name_textView.text = ItemsViewModel.name
        holder.fullname_textView.text = ItemsViewModel.full_name
        holder.des_textView.text = ItemsViewModel.description
        holder.stars_textView.text = ItemsViewModel.stargazers_count

        holder.itemView.setOnClickListener {
            val model = mList.get(position)
            val dName : String = model.name
            val dFullname : String = model.full_name
            val dDescription : String = model.description
            val dStars: String = model.stargazers_count

            val intent = Intent(context, detail_page::class.java)

            intent.putExtra("iName",dName)
            intent.putExtra("iFullname",dFullname)
            intent.putExtra("iDescription",dDescription)
            intent.putExtra("iStars",dStars)
            context.startActivity(intent)
        }
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val name_textView: TextView = itemView.findViewById(R.id.name)
        val fullname_textView: TextView = itemView.findViewById(R.id.fullname)
        val des_textView: TextView = itemView.findViewById(R.id.description)
        val stars_textView: TextView = itemView.findViewById(R.id.stars)
        //val textClick: TextView = itemView.findViewById<TextView>(R.id.name)
        //textClick.setOnClickListener {
         //   val intent = Intent(this, detail_page::class.java)
         //   startActivity(intent)
        //}
        /*
        init {
            itemView.setOnClickListener {
                listener.onItemClick(adapterPosition)
            }
        }
        */
    }
}
