package com.example.tddc73_danno126_jihry244

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
