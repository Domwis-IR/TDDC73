package com.example.projecttake2

import android.widget.EditText
import androidx.core.widget.doOnTextChanged


class PasswordStrengthMeter {
    var minLength = 8
    var maxLength = 128
    var requireLowercaseLetters = true
    var requireUppercaseLetters = true
    var requireSpecialCharacters = true
    var requireNumbers = true
    var errorMessage = ""
    val uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val lowercase = "abcdefghijklmnopqrstuvwxyz"
    val numbers = "0123456789"

    constructor(password: EditText){
        password.doOnTextChanged { text, start, before, count ->  CheckPasswordStrength(text as String)}
    }

    fun SetInputField(password: EditText){
        password.doOnTextChanged { text, start, before, count ->  CheckPasswordStrength(text as String)}
    }

    fun SetMaxLength(maxLength: Int){
        this.maxLength = maxLength
    }

    fun SetRequireLowercase(requireLowercase: Boolean){
        this.requireLowercaseLetters = requireLowercase
    }

    fun SetRequireUppercase(requireUppercase: Boolean){
        this.requireUppercaseLetters = requireUppercase
    }

    fun SetRequireNumbers(requireNumbers: Boolean){
        this.requireNumbers = requireNumbers
    }

    fun SetRequireSpecialCharacters(requireSpecialCharacters: Boolean){
        this.requireSpecialCharacters = requireSpecialCharacters
    }

    fun CheckPasswordStrength(password: String): Boolean{
        if(password.length < minLength){
            errorMessage = "Password must be at least " + minLength + " characters long"
            return false
        } else if(password.length > maxLength){
            errorMessage = "Password may be at most " + maxLength + "characters long"
            return false
        }
        var containsUppercase = false
        var containsLowercase = false
        var containsNumber = false
        var containsSpecial = false
        for (character in password){
            if(uppercase.contains(character)){
                containsUppercase = true
            } else if(lowercase.contains(character)){
                containsLowercase = true
            } else if(numbers.contains(character)){
                containsNumber = true
            } else{
                containsSpecial = true
            }
        }
        if(requireLowercaseLetters && !containsLowercase){
            errorMessage = "Password must contain a lowercase letter"
            return false
        } else if(requireUppercaseLetters && !containsUppercase){
            errorMessage = "Password must contain an uppercase letter"
            return false
        } else if (requireNumbers && !containsNumber){
            errorMessage = "Password must contain a number"
            return false
        } else if(requireSpecialCharacters && !containsSpecial){
            errorMessage = "Password must contain a special character"
            return false
        }

        errorMessage = ""
        return true
    }
}