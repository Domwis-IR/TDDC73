package com.example.projecttake2

class AccountRegistration {
    val username = true
    val firstname = true
    val lastname = true
    val password = true
    val checkpassword = true
    val email = true

//What function to be need
//After filling in all the info it needs to create new account and put it into database
//Check button for agreeing with Terms of use agreement
//Sign up button

    fun

}